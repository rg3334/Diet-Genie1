export const dietPlanSchema = {
  "Today's Diet": {
    BREAKFAST: ["FoodItem1", "FoodItem2", "FoodItem3"],
    LUNCH: ["FoodItem1", "FoodItem2", "FoodItem3"],
    DINNER: ["FoodItem1", "FoodItem2", "FoodItem3"],
  },
};
